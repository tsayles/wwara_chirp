# src/wwara_chirp/version.py
__version__ = "2.0.4"
# src/wwara_chirp/__init__.py

from .wwara_chirp import main